<script lang="ts" setup>
import Historytable from '@/components/history/Historytable.vue'
import ChartLint from '@/components/history/ChartLint.vue';
//初始化数据

</script>

<template>
  <div>

  <Historytable />
  </div>
</template>

<style scoped >

</style>