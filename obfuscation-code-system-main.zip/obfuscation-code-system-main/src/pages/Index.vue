<script lang="ts" setup>

</script>

<template>
  <div>
    <div class="w-[500px] h-[500px] mx-auto">
      <img  class="w-full h-full" src="../../public/flowpath.png" alt="">
    </div>
  </div>
</template>

<style scoped >

</style>