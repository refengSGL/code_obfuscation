<script lang="ts" setup>

</script>

<template>
  <button class="w-24 h-10 rounded-xl border-0 mx-2 hover:bg-slate-100">
    <slot>
      确定
    </slot>
  </button>
</template>

<style scoped >

</style>