<script lang="ts" setup>
//指令替换
import UploadTable from '@/components/common/UploadTable.vue';
import TcodeParameter from '@/components/encodearithmetic/TcodeParameter.vue';
</script>

<template>
  <div class="w-2/3 mx-auto">
    <UploadTable />
    <TcodeParameter />
  </div>
</template>

<style scoped >

</style>