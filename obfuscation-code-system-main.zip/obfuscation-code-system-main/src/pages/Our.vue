<script lang="ts" setup>
import UploadTable from '@/components/common/UploadTable.vue';
import Paramer from '@/components/our/Paramer.vue';

</script>

<template>
  <div class="w-2/3 mx-auto">
    <UploadTable />
    <Paramer />
  </div>
</template>

<style scoped >

</style>