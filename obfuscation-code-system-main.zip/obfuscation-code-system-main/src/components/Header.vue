<template>
    <div class="w-[1200px] mx-auto h-[70px] flex">
        <div class="w-1/3">
        </div>
        <div class="w-1/3 text-3xl text-center font-bold ">
          <div class="mt-3">
            代码混淆系统
          </div>
        </div>
        <div class="w-1/3">
          <Picture />
        </div>
    </div>
</template>
<script lang="ts" setup>
import Picture from './Picture.vue';
</script>
