<script lang="ts" setup>
//flatten扁平化
import UploadTable from '@/components/common/UploadTable.vue'
import TFparameter from '@/components/flatten/TFparameter.vue'

</script>

<template>
  <div class="w-2/3 mx-auto">
    <UploadTable />
    <TFparameter />
  </div>
</template>

<style scoped >

</style>