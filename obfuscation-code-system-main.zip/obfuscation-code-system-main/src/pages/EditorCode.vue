<script lang="ts" setup>
import CodeEditor from '@/components/common/CodeEditor.vue';
</script>

<template>
  <div>
    <div class="w-4/5 mx-auto">
      <CodeEditor></CodeEditor>
    </div>
  </div>
</template>

<style scoped >

</style>