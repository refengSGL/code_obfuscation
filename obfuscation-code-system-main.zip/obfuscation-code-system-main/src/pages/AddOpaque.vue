<script lang="ts" setup>
//不透明谓词
import UploadTable from '@/components/common/UploadTable.vue';
import TaddParameter from '@/components/addppaque/TaddParameter.vue';
</script>

<template>
  <div class="w-2/3 mx-auto">
    <UploadTable />
    <TaddParameter />
  </div>
</template>

<style scoped >

</style>