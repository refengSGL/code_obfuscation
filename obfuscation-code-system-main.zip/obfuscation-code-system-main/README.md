
运行必备环境：node

安装依赖：
npm install 
或 pnpm installl

运行命令：
npm run dev 或
pnpm run dev


管理员账号：admin
密码：111111
