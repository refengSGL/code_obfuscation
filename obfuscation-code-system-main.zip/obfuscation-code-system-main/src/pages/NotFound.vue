<script lang="ts" setup>

</script>

<template>
  <div class="text-4xl">
     404 not fund
  </div>
</template>

<style scoped >

</style>